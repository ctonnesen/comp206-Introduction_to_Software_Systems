// Christian Tonnesen
// 260847409

void parse(char record[], int *acct, float *amnt);
void findUpdate(int account, float amount);
void prettyPrint();

// This header file declares the functions for the preprocessor of ./bank
