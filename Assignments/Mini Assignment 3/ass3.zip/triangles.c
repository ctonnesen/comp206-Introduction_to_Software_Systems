/* Christian Tonnesen */

/* 260847409 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
int size;

int main (int argc, char *argv[]) {

/* Take input fron arguments */

if (argc > 2) {

	size=atoi(argv[1]);

/* If there is an argument, then take the first argument and convert to integer */
      
} else {

 printf ("One argument is expected. Please input a number: ");
	scanf("%d", &size);

/* If there is no argument, display the text and prompt the user for another input */

}

while (size<=0)  {
        printf("An incorrect triangle size was inputed. The size must be greater than 0 and an integer number. Syntax: ./triangles SIZE");
	
	printf("\n");
	
	printf("Please input a number: ");       
	
	scanf("%d", &size);

/* While the size is not above 0, output the above string and prompt the user for a correct number. In the event it isn't, it will loop */

}

for (int row = 1; row<=size; row++) {
        for (int spot=0; spot<size; spot++) {

                if (spot<(size-row)) {

                printf(" ");

/* If the current iteration of spot is less than the size minus the row, a space if printed */

                }

                else {

                printf("*");

/* A star is placed if the equation is not satisfid */
                
		}
        }

printf("\n");

}

return 0;

/* Return 0 to end the program */

}
