gcc triangles.c
