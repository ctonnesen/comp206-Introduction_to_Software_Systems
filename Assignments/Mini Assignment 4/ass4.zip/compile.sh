gcc -o matrix matrix.c
gcc -o reverse reverse.c
